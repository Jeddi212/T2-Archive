/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubesstrukdat;

/**
 *
 * @author msj
 */
public class Penggajian {
    String idTeacher;
    int tanggal;
    int bulan;
    int tahun;
    int gaji;
    Penggajian next;
}
